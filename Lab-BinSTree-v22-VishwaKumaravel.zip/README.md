There are many ways to implement the insert() and remove() functions.  The code in this lab was derived from a working version of the code.  The functioning code for insert() and remove() has been stripped out with comments replacing the code.  

Do not change the main() method which is provided for testing on repl.it.  You may want to temporarily change main.cpp for your own diagnostics, but change it back before using repl.it tests.

Note: You may want to download the files and implement your code in your favorite IDE.  However, repl.it offers the advantage of being accessible from anywhere.

The code is designed to prompt "Tree insert" for a list of integer key values.  Hit return after each key value.  A negative value indicates the end of the input.  The code then prompts for "Tree remove" for any item keys to be removed from tree.  The remove list is entered as described for the insert.

