Instructions:



https://docs.google.com/document/d/1nhCPFKrQ17EG0vldDxWfqzndScj3ENRD0X5kKXEhXYg/edit?usp=sharing


