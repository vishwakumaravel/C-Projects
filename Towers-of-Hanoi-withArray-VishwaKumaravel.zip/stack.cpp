#include<stdio.h>
#include<iostream>
#include<math.h>
#include "stack.h"
#include "disc.h"
using namespace std;

Stack::Stack()
{

}
/*
Stack::~Stack()
{
	// delete data;
}
*/


bool Stack::push(Disc* inData)
{
  //cout << "Length of arr is " << length << endl;
  if(nextIn == length+1){
    return false;
  }
  arr[nextIn] = *inData;
  //cout << "this is nextIN in push function " << nextIn << endl;  
  nextIn++;
  return true;
  
}
Disc* Stack::pop()
{
  //cout << "this is next in " << nextIn << endl;
  if(nextIn == 0){
    return NULL;
  }
  nextIn--;
  Disc* data = &arr[nextIn];
  //cout << "this is data " << data->getSize() << endl;
  return data;
}

void* Stack::top()
{
  return &arr[nextIn];
}

bool Stack::empty()
{
return nextIn == 0;
}

void Stack::display()
{
	//cout<<endl;
	Node *p1;
	p1 = pTop;
	while (p1 != NULL)
	{
		cout<< ((Disc*)(p1->data))->toString()<<"\t";
		p1 = p1->pNext;
	}
	cout<<endl;
}

