
#include<stdio.h>
#include<iostream>
#include<math.h>
#include "stack.h"
#include "disc.h"

using namespace std;

void toh(int n)
{
  int i, x;
	Disc* a;
	Disc* b;
  Disc* temp;
	Stack* t1 = new Stack();
	Stack* t2 = new Stack();
	Stack* t3 = new Stack();
	

    for (i = n; i >= 0; i--)
    {
		Disc* d = new Disc(i);
    d->setSize(i);
		//cout << d->toString();
        t1->push(d);
    }
  for(int f=0; f <= n; f++ ){
      int comp2 = t1->arr[f].getSize();
   //   cout << "Stack t1 has these disks: " << comp2 << endl;
      
    }      
  temp = t1->pop();
        t3->push(temp);
 // cout << "t3 has " << t3->arr[0].getSize() << endl;
  //t1->display();
  //t2->display();
 // t3->display();
        temp = t1->pop();
        t2->push(temp);
        temp = t3->pop();
        t2->push(temp);
        temp = t1->pop();
        t3->push(temp);
        temp = t2->pop();
        t1->push(temp);
        temp = t2->pop();
        t3->push(temp);
        temp = t1->pop();
        t3->push(temp);


   for(int j=3; j >= 0; j-- ){
     int comp = t3->arr[j].getSize();
     cout << comp << endl;
      
   }

}
int main()
{
    int n;
    cout<<"enter the number of disksn";
    cin>>n;
    toh(n);
    return 0;
}
// © 2022 GitHub, Inc.
// Terms
// Privacy
// Security
// Status
// Docs
// Contact GitHub
// Pricing
// API
// Training
// Blog
// About
// Loading complete