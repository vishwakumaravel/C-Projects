#include "disc.h"

Disc::Disc(){
  size = 5;
}

Disc::Disc(int _size){
  size = _size;
}

Disc::~Disc(){
  
}

int Disc::getSize(){
  return size;
}

void Disc::setSize(int _size){
 size = _size;
}

std::string Disc::toString(){
  
  std::string returnValue = std::to_string(size);
  return returnValue;
}
// Implement the functions protoyped in disc.h
// Your code here

