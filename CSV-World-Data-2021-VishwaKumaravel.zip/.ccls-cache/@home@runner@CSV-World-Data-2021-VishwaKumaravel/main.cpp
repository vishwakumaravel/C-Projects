#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main () {
  string line,my_country_substr, my_year_substr;
  string country_name_array [240];
  float year_array [240];
  int comma_count = 0;
  int country_marker =2;
  int year_marker = 15;
  int latch_pos = 0;
  int array_pos =0;
  int line_number = 0;
  float temp;
  string temp_str;
  ifstream myfile ("WPP2015_MORT_F07_1_LIFE_EXPECTANCY_0_BOTH_SEXES.csv");
  if (myfile.is_open()) {
    while (getline(myfile,line)) {
    if(line_number > 17) {
      for(int i=0; i< line.length();i++){
        if (line[i] == ','){
          comma_count++;   
          latch_pos = i;
          //cout << "here"<< endl;
        } // if
        if ((comma_count == country_marker)&&(i>latch_pos) ) {
          my_country_substr = my_country_substr+line[i];    
          //cout << "Country = " <<  my_country_substr<< endl;
        }
        if ((comma_count == year_marker)&&(i>latch_pos) ) {
          my_year_substr = my_year_substr+line[i];          
        }
        
      } //for loop
      country_name_array[array_pos] = my_country_substr;
      year_array[array_pos] = stof(my_year_substr);
      array_pos++;
      my_country_substr = "";
      my_year_substr = "";
      latch_pos =0;
      comma_count =0;
      } // if line_number >= 18
      line_number++;
    } //while getline 1
    myfile.close();
  } // if myfile.isopen
  else cout << "Unable to open the file";
 
  for(int x = 0; x<240; x++) {
   for(int y = x+1; y<=240; y++)
   {
      if(year_array[x] < year_array[y]) {
         temp = year_array[x];
         year_array[x] = year_array[y];
         year_array[y] = temp;
         temp_str = country_name_array[x];
         country_name_array[x] = country_name_array[y];
         country_name_array[y] = temp_str;
        } // if year array
      } // for y
   } // for x
    for(int m=0; m<240; m++) {
   cout << "Rank = " << m+1 << " Country = " << country_name_array[m] << "  Age = " << year_array[m] << endl;
 }
} // int main