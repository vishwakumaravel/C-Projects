	/* * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * 		LASAalloc.h
	 * 		LASAalloc class declaration.  
	 * 
	 * 		Do not change this file other than to add local varaibles and Functions.
	 *    Make any changes only in the provided block.
	 * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#include<iostream>
#include<stdlib.h>
#include "LASAalloc.h"

// Defines for LASAalloc buffer simulation.  
// Keep it simple, no changes to program break
#define INITIAL_MALLOC_SIZE 1000
#define MAX_MALLOC_SIZE 100000


using namespace std;

//typedef unsigned char BYTE_t;

LASAalloc::LASAalloc()
{
	brk(INITIAL_MALLOC_SIZE);
  // char *BigBuffer;
  // BigBuffer = (char *)malloc(MAX_MALLOC_SIZE);
  // cout << "printing Big buffer starting address" <<  &BigBuffer << endl;
	
	// Point to where first node will be located.
	//block* firstBlock = (block*)bufferBase;
	//freeList = firstBlock;
	
	// Configure first node on freeList
	//firstBlock->size = (int)(bufferSize);
	//firstBlock->prev_block = nullptr;
	//firstBlock->next_block = nullptr; 
	//firstBlock->this_block_data = (void*)((long long int)bufferBase+(long long int)sizeof(block)); 
	//firstBlock->freeFlag = true; 
	void* myAddress = LASAalloc::put_stamp_and_return_address (0x0,bufferBase);
  set_previous_address(&myAddress+1);
	// Show initial statistics
	//cout<<"initial statistics buffer Allocation: "<< bufferBase << " - " << brk(0) << endl;
  //cout<<"initial statistics previous_address: "<< previous_address << " - " << brk(0) << endl;
	//cout<<"initial statistics freeList: "<< freeList << " - " << brk(0) << endl;
	//cout<<"initial statistics Block header size " << sizeof(block) << endl;
	//cout<<"initial statistics integer size " << sizeof(int) << endl;
	
	display_node(freeList);

}

void* LASAalloc::put_stamp_and_return_address(int arg_size, void *arg_start_address){
  
  
  cout<<"buffer Allocation: "<< arg_start_address << " - decimal " << arg_size << endl;
	//freeList = myBlock;
  
 //handle initialization constructor
 // run this code only once (which should be during initialization)
  block* myBlock = (block*)arg_start_address + arg_size;
  myBlock->size = INITIAL_MALLOC_SIZE - (long long int)sizeof(block); // This is your available free space
	myBlock->prev_block = nullptr; 
	myBlock->next_block = nullptr; 
	myBlock->this_block_data = (void*)((long long int)arg_start_address+(long long int)sizeof(block)); 
	myBlock->freeFlag = true; 
  void* return_address = myBlock->this_block_data;
	running total of the remaining free space = calculate
  ----------------------------------------------------------------
	//Run this everytime  the main.cpp calls lalloc every time
  block* myBlock = (block*)arg_start_address + arg_size;
	myBlock->size = running total of the remaining free space - (long long int)sizeof(block) - (int)(arg_size);    
	myBlock->prev_block = arg_start_address - (long long int)sizeof(block) - 1;
	myBlock->next_block = nullptr; 
	myBlock->this_block_data = (void*)((long long int)arg_start_address+(int)(arg_size)+(long long int)sizeof(block)); 
	myBlock->freeFlag = true; 
  void* return_ending_address = myBlock->this_block_data;

  // Update previous Block with the details of the current Block
  block* prev_stamp = myBlock->prev_block;
  prev_stamp -> next_block = myBlock; 
  prev_stamp -> freeFlag = false;
  prev_stamp -> size = arg_size;
  // Store 
  store the address of the new head block = myBlock
  running total of the remaining free space = calculate
  
	// Show initial statistics
	cout<<"buffer Allocation: "<< arg_start_address << " - " << myBlock->this_block_data << endl;
	//cout<<"Block header size " << sizeof(block) << endl;
	//cout<<"integer size " << sizeof(int) << endl;
	//display_node(freeList);

  return (return_address);
}

LASAalloc::~LASAalloc()
{
}

void LASAalloc::display_node(struct block *p)
{
		cout << "Prev: " << p->prev_block;
		cout << "\tNext: " << p->next_block;
		cout << "\tFree: " << p->freeFlag;
		cout << "\tSize: " << p->size;
		cout << "\tThis: " << p->this_block_data << endl;
		cout << endl;	
}

void LASAalloc::display(struct block *begin)
{
	struct block *p;
	if(begin==NULL)
	{
		cout<<"List is empty\n";
		return;
	}
	p=begin;
	cout<<"List is :\n";
	while(p!=NULL)
	{
		display_node(p);
		p=p->next_block;
  }
	cout<<"\n";
}

void LASAalloc::set_previous_address(void* arg_add)
{
  previous_address = arg_add;
}

void* LASAalloc::get_previous_address()
{
  return previous_address;
}

void* LASAalloc::lalloc(int size)
{
  
    //void *a = (int *)malloc(size);  
  
  current_address = LASAalloc::put_stamp_and_return_address (size, get_previous_address());
  cout << "Previous address " << previous_address << endl;
  cout << "Current address " << current_address << endl;
  set_previous_address(&current_address+1);
  return current_address;
	// 1) Find out how to use malloc function to allocate 10 bytes
  // 2) Return the pointer to starting address of the first byte
}

void* LASAalloc::lfree(char* userBlock)
{
	my stamp location = userBlock - sizeof(block);
  my_stamp_location-> freeFlag = true;
  
  return nullptr;
}

void* LASAalloc::findFit(int size)
{
	get previous_address
  stamp address = previous address -sizeof(block) -1;
  traverse the linked list backwards until you get free flag = true
    if free flag is set, check if (stamp address -> size >= size + sizeof(block))
       update the size in the previous stamp block
       calculate the space left
        update the new stamp with new size (space left) in the split
        put stamp and return address
}

void* LASAalloc::split(block* target, int size)
{
	
}
 


/*
 *   >>>>>>  DO NOT CHANGE THIS SECTION  <<<<<<<
 * 
 * brk()
 * Function to simulate the libc brk() function to allocate memory for a buffer
 * 
 */

void * LASAalloc::brk(int size)
{
	
	if (size !=0)
	{
		if (bufferBase == 0)
		{
			bufferBase = malloc(size);
			bufferSize = size;
		}
		else
		{
			cout<<"buffer already locked/n";
			return 0;
		}
		
	}
  int *sum = (int*)bufferBase + bufferSize;
  cout << "starting address of the buffer = " << bufferBase << endl;
  cout << "this is size " << size << endl;
  //cout << "sum is = to" << sum << endl;
	return sum;
}