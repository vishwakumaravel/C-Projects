/*
 * LaQueue
 * 
 * 
 * This is part of a series of labs for the Liberal Arts and Science Academy.
 * The series of labs provides a mockup of an POSIX Operating System
 * referred to as LA(SA)nix or LAnix.
 *  
 * (c) copyright 2018, James Shockey - all rights reserved
 * 
 * */

#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include "PQueue.h"



/*
 * Class Priority Queue
 */

		
/*
* Insert into Priority Queue
*/
bool PQueue::push(void *item, int priority)
{
  if(((end + 1) % length) == start){
    return false;
  }
  end = (end + 1) % length;
  node* item_toadd = new node();
  item_toadd->data = item;
  queue[end] = *item_toadd;
  if(start == -1){
    start = 0;
  }
  return true;
}

/*
 * Delete from Priority Queue
 */
void* PQueue::top()
{
	void* t = queue[start].data;
  return t;
}
/*
 * Delete from Priority Queue
 */
void PQueue::pop()
{
  if(start == -1){
    return; NULL;
  }
  if(start==end){
    start = end = -1;
  }
  else{
    start = (start+1) % length;
  }
}

/*
 * Print Priority Queue
 */
void PQueue::display()
{

for(int item = 0; item < length; item++){
 	std::cout<<" "<<(char*)queue[item].data<<std::endl; 
}
	
	/* Use the following out command for the data */

}
	