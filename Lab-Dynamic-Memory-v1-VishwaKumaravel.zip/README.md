Instructions at:

https://docs.google.com/document/d/1F8O8PZu9ZknXrOZKxM3YyHo25ViGzII0kEhdwU2hLvc/edit?usp=sharing